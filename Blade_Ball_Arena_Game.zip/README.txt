BLADE BALL ARENA

How to play:
1. Open index.html in Chrome, Safari, Edge or Firefox.
2. Pick a fighter.
3. Press PLAY.

Controls:
- Move: WASD or arrow keys
- Deflect: Space
- Dash: Shift
- Special power: E
- On phones and tablets, use the on-screen stick and buttons.

Included fighters:
- Lightning Legend
- Galaxy Person
- Yin Yang
- Golden Hero
- Void Warrior

This is a small single-player browser game. It runs offline and does not need Roblox.
